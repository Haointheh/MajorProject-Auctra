// src/pages/BrowseCategoriesPage.jsx
// Reached from: Navbar's "Browse All" (desktop + mobile subnav), and the
// homepage hero's "Browse Auctions" button. Clicking a card goes straight
// to the existing category page (/auctions/:slug) already wired up in
// Navbar's CATEGORIES / CategoryPage.

import { useNavigate } from "react-router-dom";
import PageHeader from "../ui/PageHeader";
import CardType2 from "../ui/CardType2";
import art from "../assets/art.jpg";
import fashion from "../assets/fashion.jpg";
import jewellery from "../assets/jewellery.jpg";
import antiques from "../assets/antiques.jpg";
import handicraft from "../assets/handicraft.jpg";

const CATEGORIES = [
  {
    slug: "art",
    title: "Art and Paintings",
    description: "Rare pieces and fine art from established and emerging artists",
    imageUrl: art,
  },
  {
    slug: "fashion",
    title: "Fashion and Styling",
    description: "Trendy pieces and exclusive collections",
    imageUrl: fashion,
  },
  {
    slug: "jewellery",
    title: "Jewellery and Accessories",
    description: "Exquisite pieces for every occasion",
    imageUrl: jewellery,
  },
  {
    slug: "antiques",
    title: "Antiques and Vintage",
    description: "Rare items and collectibles",
    imageUrl: antiques,
  },
  {
    slug: "handicrafts",
    title: "Handicrafts",
    description: "Built with historical skills and craftsmanship",
    imageUrl: handicraft,
  },
];

export default function BrowseCategoriesPage() {
  const navigate = useNavigate();

  return (
    <main className="min-h-screen bg-neutral1">
      <PageHeader
        eyebrow="Auctra"
        title="Browse All Categories"
        subtitle="Pick a category to see everything currently up for auction."
      />

      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {CATEGORIES.map((cat) => (
            <CardType2
              key={cat.slug}
              title={cat.title}
              description={cat.description}
              imageUrl={cat.imageUrl}
              onClick={() => navigate(`/auctions/${cat.slug}`)}
            />
          ))}
        </div>
      </div>
    </main>
  );
}
