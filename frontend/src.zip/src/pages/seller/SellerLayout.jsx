import DashboardLayout from "../../components/layouts/DashboardLayout";

const SELLER_NAV = [
  { label: "Overview",       path: "/seller/dashboard",          icon: "▦" },
  { label: "My Listings",    path: "/seller/dashboard/auctions", icon: "☰" },
  { label: "Create Auction", path: "/seller/dashboard/create",   icon: "＋" },
];

export default function SellerLayout() {
  return <DashboardLayout navItems={SELLER_NAV} roleLabel="Seller Hub" />;
}

// import DashboardLayout from "../../components/layouts/DashboardLayout";

// const SELLER_NAV = [
//   { label: "Overview",       path: "/seller/dashboard",          icon: "▦" },
//   { label: "My Listings",    path: "/seller/dashboard/auctions", icon: "☰" },
//   { label: "Create Auction", path: "/seller/dashboard/create",   icon: "＋" },
// ];

// export default function SellerLayout() {
//   return (
//     <DashboardLayout
//       navItems={SELLER_NAV}
//       roleLabel="Seller Hub"
//       homePath="/seller/dashboard/auctions"
//       showBackToSite={false}
//     />
//   );
// }